
	package com.info6255.group1.selenium.testscenarios;



	import static org.testng.Assert.fail;



	import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.NoAlertPresentException;
	import org.openqa.selenium.NoSuchElementException;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.testng.annotations.AfterClass;
	import org.testng.annotations.BeforeMethod;
	import org.testng.annotations.Test;



	public class Scenario4AddToCart {
	@Test (priority = 5)
	public class UntitledTestCase {

	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	JavascriptExecutor js;
	@SuppressWarnings("deprecation")
	@BeforeMethod
	public void setUp() throws Exception {
	//Drive path
	System.setProperty("webdriver.chrome.driver", "/Users/sahilbagwan/Downloads/selenium/chromedriver");
	driver = new ChromeDriver();
	driver.manage().window().maximize();

	baseUrl = "https://www.google.com/";
	driver.manage().timeouts();
	js = (JavascriptExecutor) driver;
	}



	public void testUntitledTestCase() throws Exception {
	//Step 1: Open source link
	driver.get("https://northeastern.bncollege.com/");
	Thread.sleep(3000);
	// driver.findElement(By.xpath("//button[[@ADD TO CART, 'submit' and [text()='New']]")).click();




	driver.findElement(By.linkText("STUDENT ESSENTIALS")).click();
	Thread.sleep(3000);
	driver.findElement(By.xpath("//*[@id=\"facet-Sale\"]/div/ul/li[1]/form/label/span/span[2]/span[1]")).click();
	Thread.sleep(3000);
	driver.findElement(By.xpath("/html/body/main/div[3]/div[3]/div[5]/div[2]/div[3]/div/div[4]/div[1]/a/img")).click();
	Thread.sleep(1000);

	driver.findElement(By.linkText("ADD TO CART")).click();

	Thread.sleep(5000);

	// password.sendKeys("RITani@@@252525");
	//Step 5: Select a category
	// driver.findElement(By.xpath("//*[@id=\"6\"]")).click();
	// //ERROR: Caught exception [ERROR: Unsupported command [selectFrame | relative=parent | ]]
	// //Step 6: Select a product
	// driver.findElement(By.xpath("//button[@type='button']")).click();
	// driver.findElement(By.linkText("Northeastern Huskies Top of the World Triple Threat Hat - Red")).click();
	// //Step 7: Add to cart
	// driver.findElement(By.xpath("/html/body/div[2]/div/div[5]/div[2]/div[13]/div/div/div[5]/div/div[2]/div/div/div/button")).click();
	// //Step 8: Open cart
	// driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/header/div[2]/div/a/i")).click();
	//

	// driver.findElement(By.id("6")).click();
	// driver.findElement(By.xpath("//img[@alt='Northeastern Huskies Top of the World Triple Threat Hat - Red']")).click();
	// driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Quantity'])[2]/following::button[1]")).click();
	// driver.findElement(By.xpath("//button/span/i")).click();
	// //ERROR: Caught exception [ERROR: Unsupported command [selectWindow | win_ser_local | ]]
	// driver.close();
	// //ERROR: Caught exception [ERROR: Unsupported command [selectWindow | win_ser_local | ]]
	// driver.get("https://northeastern.bncollege.com/");
	// driver.findElement(By.xpath("//section[@id='headerDesktopView']/nav/ul/li[2]")).click();
	// driver.findElement(By.linkText("Apparel & Spirit Shop")).click();
	}



	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
	driver.quit();
	String verificationErrorString = verificationErrors.toString();
	if (!"".equals(verificationErrorString)) {
	fail(verificationErrorString);
	}
	}



	private boolean isElementPresent(By by) {
	try {
	driver.findElement(by);
	return true;
	} catch (NoSuchElementException e) {
	return false;
	}
	}



	private boolean isAlertPresent() {
	try {
	driver.switchTo().alert();
	return true;
	} catch (NoAlertPresentException e) {
	return false;
	}
	}




	}
	}


