package com.info6255.group1.selenium.testscenarios;

import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.info6255.group1.selenium.Utils;

public class Scenario1AddToFavorites {
	
//Creating new logger
	
	static Logger logger = Logger.getLogger(Scenario1AddToFavorites.class.getName());

	public static void runScenario(WebDriver driver, ExtentTest test) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, 1000);
		
//		Selecting the search input
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		
//Selecting he search button for services and links and finding course descriptions
		WebElement e = wait.until(ExpectedConditions
				.elementToBeClickable(driver.findElement(By.xpath("/html/body/div/section[1]/div/div[2]/div/input"))));
		e.sendKeys(new String[] { "Course Descriptions" });
		
		
// Entering course description in the search bar
		Utils.takeScreenShot(driver, "scenario1_enter_in_search");
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		
//Adding the course descriptions in the favorites
		
		driver.findElement(By.xpath("//i[@data-gtm-event-action=\"Course Descriptions\"]")).click();
		Utils.takeScreenShot(driver, "scenario1_add_fav");

		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		Thread.sleep(2000);
		
		driver.navigate().refresh();
		Thread.sleep(3000);


	}

}
