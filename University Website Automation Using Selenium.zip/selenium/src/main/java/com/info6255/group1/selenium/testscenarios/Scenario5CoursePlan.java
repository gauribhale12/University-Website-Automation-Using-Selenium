package com.info6255.group1.selenium.testscenarios;

import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

//import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.info6255.group1.selenium.Utils;

//TODO Call Utils.takeScreenShot(driver, "filename") wherever necessary for before + after actions
public class Scenario5CoursePlan {

	static Logger logger = Logger.getLogger(Scenario5CoursePlan.class.getName());

	public static void runScenario(WebDriver driver, ExtentTest test) throws InterruptedException {
		
		WebDriverWait wait = new WebDriverWait(driver, 100);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        //Step 1 - Go to Course Registration

        //Step1a - click on services and links tab

        Thread.sleep(1000);
        WebElement serviceslink = driver.findElement(By.linkText("Services & Links"));
        Utils.takeScreenShot(driver, "Scenario5_HomePage");
        serviceslink.click();
        Utils.takeScreenShot(driver, "Scenario5_Services&Links_clicked");



        Thread.sleep(3000);



        Utils.takeScreenShot(driver, "Scenario5_Before_Course_Reg");



        //Step1b - click on Course Registration option



        driver.findElement(By.xpath("//*[@id=\"portlet_com_liferay_asset_publisher_web_portlet_AssetPublisherPortlet_INSTANCE_VGn3ZknJvwnV\"]/div/div/div/div[5]/div[2]/div/div[1]/div[2]/a")).click();



        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);



        String handle = driver.getWindowHandle();



        Utils.takeScreenShot(driver, "Scenario5_After_Course_Reg");



        // Switch to new window to open Banner



        for (String handles : driver.getWindowHandles()) {



            if (handles.equals(handle))



                continue;



            driver.switchTo().window(handles);







        }



        Utils.takeScreenShot(driver, "Scenario5_After_Course_Reg");







        //c) Select “Plan Ahead” and select Spring 2022 course



        Thread.sleep(1000);



        WebElement planninglink = driver.findElement(By.id("planningLink"));



        planninglink.click();



        Thread.sleep(1000);



        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);







        Utils.takeScreenShot(driver, "Scenario5_Before_Semester_Select");







        // select term in order to create a plan



        wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id("s2id_txt_term")))).click();



        WebElement semSearch = driver.findElement(By.id("s2id_autogen1_search"));



        Thread.sleep(10);



        semSearch.sendKeys("Spring 2022 Semester");



        Thread.sleep(10);



        logger.log(Level.INFO, "Selecting semester Spring 2022");



        //wait = new WebDriverWait(driver, 500);



        Thread.sleep(500);



        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);



        WebElement term = driver.findElement(By.xpath("//div[@id=\"202230\"]"));



        term.click();



        Thread.sleep(100);



        Utils.takeScreenShot(driver, "Scenario5_After_Semester_Select");



        driver.findElement(By.id("term-go")).click();







        //d) Create plan



        // Search course and add them to create a plan



        logger.log(Level.INFO, "Clicking create plan");



        Thread.sleep(1000);



        WebElement createplanbutton = driver.findElement(By.id("createPlan"));



        createplanbutton.click();



        logger.log(Level.INFO, "entering course number");



        Thread.sleep(100);



        WebElement keyword = driver.findElement(By.xpath("//input[@id='txt_keywordlike']"));



        keyword.sendKeys("INFO5100");



        Thread.sleep(100);



        Utils.takeScreenShot(driver, "Scenario5_Before_Search_Course");



        wait = new WebDriverWait(driver, 500);



        wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id("search-go")))).click();



        logger.log(Level.INFO, "searched course, waiting to load...");



        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);







        // Using xpath to find the button Add Course to the Plan







        WebElement selectedCourse = driver.findElement(By.xpath("//*[@id=\"table1\"]/tbody/tr/td[6]/div/button[2]"));



        selectedCourse.click();



        Utils.takeScreenShot(driver, "Scenario5_After_Search_Course");



        logger.log(Level.INFO, "Clicked add course button");



        Thread.sleep(100);



        WebElement savebtn = driver.findElement(By.xpath("//*[@id=\"saveButton\"]"));



        savebtn.click();



        Thread.sleep(100);



        logger.log(Level.INFO, "Clicked save plan button");



        Utils.takeScreenShot(driver, "scenario5_before_save_plan");



        Thread.sleep(1000);



        WebElement planname = driver.findElement(By.id("txt_planDesc"));



        planname.sendKeys("plan1");



        Thread.sleep(1000);



        logger.log(Level.INFO, "input plan name");



        logger.log(Level.INFO, "clicking save...");



        //driver.findElement(By.xpath("/html/body/div[14]/div[3]/div/button[2]")).click();



        Thread.sleep(100);



        WebElement plansavebtn = driver.findElement(By.xpath("(//button[contains(text(),'Save')])[2]"));



        plansavebtn.click();



        Thread.sleep(1000);



        //altername XPATH - /html/body/div[14]/div[3]/div/button[2]



        Utils.takeScreenShot(driver, "scenario5_after_save_plan");



        logger.log(Level.INFO, "Saved the plan");



        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);







        test.log(Status.INFO, "Expected: Create a Course plan, Actual: Course plan - plan1 created successfully");	}
}